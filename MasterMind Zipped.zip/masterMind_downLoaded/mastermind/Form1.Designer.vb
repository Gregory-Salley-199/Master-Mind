﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnCheck = New System.Windows.Forms.Button()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.PegPlace78 = New WindowsApplication2.pegPlace()
        Me.PegPlace77 = New WindowsApplication2.pegPlace()
        Me.PegPlace76 = New WindowsApplication2.pegPlace()
        Me.PegPlace75 = New WindowsApplication2.pegPlace()
        Me.PegPlace74 = New WindowsApplication2.pegPlace()
        Me.PegPlace73 = New WindowsApplication2.pegPlace()
        Me.PegPlace72 = New WindowsApplication2.pegPlace()
        Me.PegPlace71 = New WindowsApplication2.pegPlace()
        Me.PegPlace70 = New WindowsApplication2.pegPlace()
        Me.PegPlace69 = New WindowsApplication2.pegPlace()
        Me.PegPlace68 = New WindowsApplication2.pegPlace()
        Me.PegPlace67 = New WindowsApplication2.pegPlace()
        Me.PegPlace66 = New WindowsApplication2.pegPlace()
        Me.PegPlace65 = New WindowsApplication2.pegPlace()
        Me.PegPlace64 = New WindowsApplication2.pegPlace()
        Me.PegPlace63 = New WindowsApplication2.pegPlace()
        Me.PegPlace62 = New WindowsApplication2.pegPlace()
        Me.PegPlace61 = New WindowsApplication2.pegPlace()
        Me.PegPlace60 = New WindowsApplication2.pegPlace()
        Me.PegPlace59 = New WindowsApplication2.pegPlace()
        Me.PegPlace58 = New WindowsApplication2.pegPlace()
        Me.PegPlace57 = New WindowsApplication2.pegPlace()
        Me.PegPlace56 = New WindowsApplication2.pegPlace()
        Me.PegPlace55 = New WindowsApplication2.pegPlace()
        Me.PegPlace54 = New WindowsApplication2.pegPlace()
        Me.PegPlace53 = New WindowsApplication2.pegPlace()
        Me.PegPlace52 = New WindowsApplication2.pegPlace()
        Me.PegPlace51 = New WindowsApplication2.pegPlace()
        Me.PegPlace50 = New WindowsApplication2.pegPlace()
        Me.PegPlace49 = New WindowsApplication2.pegPlace()
        Me.PegPlace48 = New WindowsApplication2.pegPlace()
        Me.PegPlace47 = New WindowsApplication2.pegPlace()
        Me.PegPlace46 = New WindowsApplication2.pegPlace()
        Me.PegPlace45 = New WindowsApplication2.pegPlace()
        Me.PegPlace44 = New WindowsApplication2.pegPlace()
        Me.PegPlace43 = New WindowsApplication2.pegPlace()
        Me.PegPlace42 = New WindowsApplication2.pegPlace()
        Me.PegPlace41 = New WindowsApplication2.pegPlace()
        Me.PegPlace40 = New WindowsApplication2.pegPlace()
        Me.PegPlace39 = New WindowsApplication2.pegPlace()
        Me.PegPlace38 = New WindowsApplication2.pegPlace()
        Me.PegPlace37 = New WindowsApplication2.pegPlace()
        Me.PegPlace36 = New WindowsApplication2.pegPlace()
        Me.PegPlace35 = New WindowsApplication2.pegPlace()
        Me.PegPlace34 = New WindowsApplication2.pegPlace()
        Me.PegPlace33 = New WindowsApplication2.pegPlace()
        Me.PegPlace32 = New WindowsApplication2.pegPlace()
        Me.PegPlace31 = New WindowsApplication2.pegPlace()
        Me.PegPlace30 = New WindowsApplication2.pegPlace()
        Me.PegPlace29 = New WindowsApplication2.pegPlace()
        Me.PegPlace28 = New WindowsApplication2.pegPlace()
        Me.PegPlace27 = New WindowsApplication2.pegPlace()
        Me.PegPlace26 = New WindowsApplication2.pegPlace()
        Me.PegPlace25 = New WindowsApplication2.pegPlace()
        Me.PegPlace24 = New WindowsApplication2.pegPlace()
        Me.PegPlace23 = New WindowsApplication2.pegPlace()
        Me.PegPlace22 = New WindowsApplication2.pegPlace()
        Me.PegPlace21 = New WindowsApplication2.pegPlace()
        Me.PegPlace20 = New WindowsApplication2.pegPlace()
        Me.PegPlace19 = New WindowsApplication2.pegPlace()
        Me.PegPlace18 = New WindowsApplication2.pegPlace()
        Me.PegPlace17 = New WindowsApplication2.pegPlace()
        Me.PegPlace16 = New WindowsApplication2.pegPlace()
        Me.PegPlace15 = New WindowsApplication2.pegPlace()
        Me.PegPlace14 = New WindowsApplication2.pegPlace()
        Me.PegPlace13 = New WindowsApplication2.pegPlace()
        Me.PegPlace12 = New WindowsApplication2.pegPlace()
        Me.PegPlace11 = New WindowsApplication2.pegPlace()
        Me.PegPlace10 = New WindowsApplication2.pegPlace()
        Me.PegPlace9 = New WindowsApplication2.pegPlace()
        Me.PegPlace8 = New WindowsApplication2.pegPlace()
        Me.PegPlace7 = New WindowsApplication2.pegPlace()
        Me.PegPlace6 = New WindowsApplication2.pegPlace()
        Me.PegPlace5 = New WindowsApplication2.pegPlace()
        Me.PegPlace4 = New WindowsApplication2.pegPlace()
        Me.PegPlace3 = New WindowsApplication2.pegPlace()
        Me.PegPlace2 = New WindowsApplication2.pegPlace()
        Me.PegPlace1 = New WindowsApplication2.pegPlace()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCheck
        '
        Me.btnCheck.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCheck.Enabled = False
        Me.btnCheck.Location = New System.Drawing.Point(33, 689)
        Me.btnCheck.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.Size = New System.Drawing.Size(204, 35)
        Me.btnCheck.TabIndex = 44
        Me.btnCheck.Text = "Check"
        Me.btnCheck.UseVisualStyleBackColor = True
        '
        'btnNew
        '
        Me.btnNew.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnNew.Enabled = False
        Me.btnNew.Location = New System.Drawing.Point(33, 734)
        Me.btnNew.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(204, 35)
        Me.btnNew.TabIndex = 45
        Me.btnNew.Text = "New Game"
        Me.btnNew.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripComboBox1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(270, 37)
        Me.MenuStrip1.TabIndex = 65
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(180, 33)
        '
        'PegPlace78
        '
        Me.PegPlace78.CMSEnabled = False
        Me.PegPlace78.Location = New System.Drawing.Point(198, 495)
        Me.PegPlace78.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace78.Name = "PegPlace78"
        Me.PegPlace78.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace78.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace78.TabIndex = 89
        Me.PegPlace78.Text = "PegPlace78"
        '
        'PegPlace77
        '
        Me.PegPlace77.CMSEnabled = False
        Me.PegPlace77.Location = New System.Drawing.Point(165, 495)
        Me.PegPlace77.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace77.Name = "PegPlace77"
        Me.PegPlace77.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace77.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace77.TabIndex = 88
        Me.PegPlace77.Text = "PegPlace77"
        '
        'PegPlace76
        '
        Me.PegPlace76.CMSEnabled = False
        Me.PegPlace76.Location = New System.Drawing.Point(132, 495)
        Me.PegPlace76.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace76.Name = "PegPlace76"
        Me.PegPlace76.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace76.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace76.TabIndex = 87
        Me.PegPlace76.Text = "PegPlace76"
        '
        'PegPlace75
        '
        Me.PegPlace75.CMSEnabled = False
        Me.PegPlace75.Location = New System.Drawing.Point(99, 495)
        Me.PegPlace75.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace75.Name = "PegPlace75"
        Me.PegPlace75.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace75.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace75.TabIndex = 86
        Me.PegPlace75.Text = "PegPlace75"
        '
        'PegPlace74
        '
        Me.PegPlace74.CMSEnabled = False
        Me.PegPlace74.Location = New System.Drawing.Point(66, 495)
        Me.PegPlace74.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace74.Name = "PegPlace74"
        Me.PegPlace74.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace74.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace74.TabIndex = 85
        Me.PegPlace74.Text = "PegPlace74"
        '
        'PegPlace73
        '
        Me.PegPlace73.CMSEnabled = False
        Me.PegPlace73.Location = New System.Drawing.Point(33, 495)
        Me.PegPlace73.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace73.Name = "PegPlace73"
        Me.PegPlace73.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace73.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace73.TabIndex = 84
        Me.PegPlace73.Text = "PegPlace73"
        '
        'PegPlace72
        '
        Me.PegPlace72.CMSEnabled = False
        Me.PegPlace72.Location = New System.Drawing.Point(198, 462)
        Me.PegPlace72.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace72.Name = "PegPlace72"
        Me.PegPlace72.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace72.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace72.TabIndex = 83
        Me.PegPlace72.Text = "PegPlace72"
        '
        'PegPlace71
        '
        Me.PegPlace71.CMSEnabled = False
        Me.PegPlace71.Location = New System.Drawing.Point(165, 462)
        Me.PegPlace71.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace71.Name = "PegPlace71"
        Me.PegPlace71.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace71.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace71.TabIndex = 82
        Me.PegPlace71.Text = "PegPlace71"
        '
        'PegPlace70
        '
        Me.PegPlace70.CMSEnabled = False
        Me.PegPlace70.Location = New System.Drawing.Point(132, 462)
        Me.PegPlace70.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace70.Name = "PegPlace70"
        Me.PegPlace70.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace70.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace70.TabIndex = 81
        Me.PegPlace70.Text = "PegPlace70"
        '
        'PegPlace69
        '
        Me.PegPlace69.CMSEnabled = False
        Me.PegPlace69.Location = New System.Drawing.Point(99, 462)
        Me.PegPlace69.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace69.Name = "PegPlace69"
        Me.PegPlace69.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace69.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace69.TabIndex = 80
        Me.PegPlace69.Text = "PegPlace69"
        '
        'PegPlace68
        '
        Me.PegPlace68.CMSEnabled = False
        Me.PegPlace68.Location = New System.Drawing.Point(66, 462)
        Me.PegPlace68.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace68.Name = "PegPlace68"
        Me.PegPlace68.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace68.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace68.TabIndex = 79
        Me.PegPlace68.Text = "PegPlace68"
        '
        'PegPlace67
        '
        Me.PegPlace67.CMSEnabled = False
        Me.PegPlace67.Location = New System.Drawing.Point(33, 462)
        Me.PegPlace67.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace67.Name = "PegPlace67"
        Me.PegPlace67.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace67.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace67.TabIndex = 78
        Me.PegPlace67.Text = "PegPlace67"
        '
        'PegPlace66
        '
        Me.PegPlace66.CMSEnabled = False
        Me.PegPlace66.Location = New System.Drawing.Point(198, 428)
        Me.PegPlace66.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace66.Name = "PegPlace66"
        Me.PegPlace66.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace66.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace66.TabIndex = 77
        Me.PegPlace66.Text = "PegPlace66"
        '
        'PegPlace65
        '
        Me.PegPlace65.CMSEnabled = False
        Me.PegPlace65.Location = New System.Drawing.Point(165, 428)
        Me.PegPlace65.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace65.Name = "PegPlace65"
        Me.PegPlace65.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace65.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace65.TabIndex = 76
        Me.PegPlace65.Text = "PegPlace65"
        '
        'PegPlace64
        '
        Me.PegPlace64.CMSEnabled = False
        Me.PegPlace64.Location = New System.Drawing.Point(132, 428)
        Me.PegPlace64.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace64.Name = "PegPlace64"
        Me.PegPlace64.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace64.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace64.TabIndex = 75
        Me.PegPlace64.Text = "PegPlace64"
        '
        'PegPlace63
        '
        Me.PegPlace63.CMSEnabled = False
        Me.PegPlace63.Location = New System.Drawing.Point(99, 428)
        Me.PegPlace63.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace63.Name = "PegPlace63"
        Me.PegPlace63.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace63.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace63.TabIndex = 74
        Me.PegPlace63.Text = "PegPlace63"
        '
        'PegPlace62
        '
        Me.PegPlace62.CMSEnabled = False
        Me.PegPlace62.Location = New System.Drawing.Point(66, 428)
        Me.PegPlace62.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace62.Name = "PegPlace62"
        Me.PegPlace62.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace62.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace62.TabIndex = 73
        Me.PegPlace62.Text = "PegPlace62"
        '
        'PegPlace61
        '
        Me.PegPlace61.CMSEnabled = False
        Me.PegPlace61.Location = New System.Drawing.Point(33, 428)
        Me.PegPlace61.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace61.Name = "PegPlace61"
        Me.PegPlace61.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace61.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace61.TabIndex = 72
        Me.PegPlace61.Text = "PegPlace61"
        '
        'PegPlace60
        '
        Me.PegPlace60.CMSEnabled = False
        Me.PegPlace60.Location = New System.Drawing.Point(198, 394)
        Me.PegPlace60.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace60.Name = "PegPlace60"
        Me.PegPlace60.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace60.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace60.TabIndex = 71
        Me.PegPlace60.Text = "PegPlace60"
        '
        'PegPlace59
        '
        Me.PegPlace59.CMSEnabled = False
        Me.PegPlace59.Location = New System.Drawing.Point(165, 394)
        Me.PegPlace59.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace59.Name = "PegPlace59"
        Me.PegPlace59.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace59.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace59.TabIndex = 70
        Me.PegPlace59.Text = "PegPlace59"
        '
        'PegPlace58
        '
        Me.PegPlace58.CMSEnabled = False
        Me.PegPlace58.Location = New System.Drawing.Point(132, 394)
        Me.PegPlace58.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace58.Name = "PegPlace58"
        Me.PegPlace58.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace58.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace58.TabIndex = 69
        Me.PegPlace58.Text = "PegPlace58"
        '
        'PegPlace57
        '
        Me.PegPlace57.CMSEnabled = False
        Me.PegPlace57.Location = New System.Drawing.Point(99, 394)
        Me.PegPlace57.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace57.Name = "PegPlace57"
        Me.PegPlace57.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace57.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace57.TabIndex = 68
        Me.PegPlace57.Text = "PegPlace57"
        '
        'PegPlace56
        '
        Me.PegPlace56.CMSEnabled = False
        Me.PegPlace56.Location = New System.Drawing.Point(66, 394)
        Me.PegPlace56.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace56.Name = "PegPlace56"
        Me.PegPlace56.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace56.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace56.TabIndex = 67
        Me.PegPlace56.Text = "PegPlace56"
        '
        'PegPlace55
        '
        Me.PegPlace55.CMSEnabled = False
        Me.PegPlace55.Location = New System.Drawing.Point(33, 394)
        Me.PegPlace55.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace55.Name = "PegPlace55"
        Me.PegPlace55.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace55.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace55.TabIndex = 66
        Me.PegPlace55.Text = "PegPlace55"
        '
        'PegPlace54
        '
        Me.PegPlace54.CMSEnabled = False
        Me.PegPlace54.Location = New System.Drawing.Point(198, 360)
        Me.PegPlace54.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace54.Name = "PegPlace54"
        Me.PegPlace54.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace54.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace54.TabIndex = 63
        Me.PegPlace54.Text = "PegPlace54"
        '
        'PegPlace53
        '
        Me.PegPlace53.CMSEnabled = False
        Me.PegPlace53.Location = New System.Drawing.Point(165, 360)
        Me.PegPlace53.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace53.Name = "PegPlace53"
        Me.PegPlace53.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace53.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace53.TabIndex = 62
        Me.PegPlace53.Text = "PegPlace53"
        '
        'PegPlace52
        '
        Me.PegPlace52.CMSEnabled = False
        Me.PegPlace52.Location = New System.Drawing.Point(198, 326)
        Me.PegPlace52.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace52.Name = "PegPlace52"
        Me.PegPlace52.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace52.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace52.TabIndex = 61
        Me.PegPlace52.Text = "PegPlace52"
        '
        'PegPlace51
        '
        Me.PegPlace51.CMSEnabled = False
        Me.PegPlace51.Location = New System.Drawing.Point(165, 326)
        Me.PegPlace51.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace51.Name = "PegPlace51"
        Me.PegPlace51.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace51.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace51.TabIndex = 60
        Me.PegPlace51.Text = "PegPlace51"
        '
        'PegPlace50
        '
        Me.PegPlace50.CMSEnabled = False
        Me.PegPlace50.Location = New System.Drawing.Point(198, 292)
        Me.PegPlace50.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace50.Name = "PegPlace50"
        Me.PegPlace50.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace50.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace50.TabIndex = 59
        Me.PegPlace50.Text = "PegPlace50"
        '
        'PegPlace49
        '
        Me.PegPlace49.CMSEnabled = False
        Me.PegPlace49.Location = New System.Drawing.Point(165, 292)
        Me.PegPlace49.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace49.Name = "PegPlace49"
        Me.PegPlace49.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace49.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace49.TabIndex = 58
        Me.PegPlace49.Text = "PegPlace49"
        '
        'PegPlace48
        '
        Me.PegPlace48.CMSEnabled = False
        Me.PegPlace48.Location = New System.Drawing.Point(198, 258)
        Me.PegPlace48.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace48.Name = "PegPlace48"
        Me.PegPlace48.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace48.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace48.TabIndex = 57
        Me.PegPlace48.Text = "PegPlace48"
        '
        'PegPlace47
        '
        Me.PegPlace47.CMSEnabled = False
        Me.PegPlace47.Location = New System.Drawing.Point(165, 258)
        Me.PegPlace47.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace47.Name = "PegPlace47"
        Me.PegPlace47.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace47.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace47.TabIndex = 56
        Me.PegPlace47.Text = "PegPlace47"
        '
        'PegPlace46
        '
        Me.PegPlace46.CMSEnabled = False
        Me.PegPlace46.Location = New System.Drawing.Point(198, 225)
        Me.PegPlace46.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace46.Name = "PegPlace46"
        Me.PegPlace46.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace46.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace46.TabIndex = 55
        Me.PegPlace46.Text = "PegPlace46"
        '
        'PegPlace45
        '
        Me.PegPlace45.CMSEnabled = False
        Me.PegPlace45.Location = New System.Drawing.Point(165, 225)
        Me.PegPlace45.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace45.Name = "PegPlace45"
        Me.PegPlace45.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace45.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace45.TabIndex = 54
        Me.PegPlace45.Text = "PegPlace45"
        '
        'PegPlace44
        '
        Me.PegPlace44.CMSEnabled = False
        Me.PegPlace44.Location = New System.Drawing.Point(198, 191)
        Me.PegPlace44.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace44.Name = "PegPlace44"
        Me.PegPlace44.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace44.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace44.TabIndex = 53
        Me.PegPlace44.Text = "PegPlace44"
        '
        'PegPlace43
        '
        Me.PegPlace43.CMSEnabled = False
        Me.PegPlace43.Location = New System.Drawing.Point(165, 191)
        Me.PegPlace43.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace43.Name = "PegPlace43"
        Me.PegPlace43.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace43.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace43.TabIndex = 52
        Me.PegPlace43.Text = "PegPlace43"
        '
        'PegPlace42
        '
        Me.PegPlace42.CMSEnabled = False
        Me.PegPlace42.Location = New System.Drawing.Point(198, 157)
        Me.PegPlace42.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace42.Name = "PegPlace42"
        Me.PegPlace42.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace42.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace42.TabIndex = 51
        Me.PegPlace42.Text = "PegPlace42"
        '
        'PegPlace41
        '
        Me.PegPlace41.CMSEnabled = False
        Me.PegPlace41.Location = New System.Drawing.Point(165, 157)
        Me.PegPlace41.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace41.Name = "PegPlace41"
        Me.PegPlace41.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace41.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace41.TabIndex = 50
        Me.PegPlace41.Text = "PegPlace41"
        '
        'PegPlace40
        '
        Me.PegPlace40.CMSEnabled = False
        Me.PegPlace40.Location = New System.Drawing.Point(198, 123)
        Me.PegPlace40.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace40.Name = "PegPlace40"
        Me.PegPlace40.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace40.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace40.TabIndex = 49
        Me.PegPlace40.Text = "PegPlace40"
        '
        'PegPlace39
        '
        Me.PegPlace39.CMSEnabled = False
        Me.PegPlace39.Location = New System.Drawing.Point(165, 123)
        Me.PegPlace39.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace39.Name = "PegPlace39"
        Me.PegPlace39.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace39.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace39.TabIndex = 48
        Me.PegPlace39.Text = "PegPlace39"
        '
        'PegPlace38
        '
        Me.PegPlace38.CMSEnabled = False
        Me.PegPlace38.Location = New System.Drawing.Point(198, 58)
        Me.PegPlace38.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace38.Name = "PegPlace38"
        Me.PegPlace38.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace38.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace38.TabIndex = 47
        Me.PegPlace38.Text = "PegPlace38"
        '
        'PegPlace37
        '
        Me.PegPlace37.CMSEnabled = False
        Me.PegPlace37.Location = New System.Drawing.Point(165, 58)
        Me.PegPlace37.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace37.Name = "PegPlace37"
        Me.PegPlace37.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace37.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace37.TabIndex = 46
        Me.PegPlace37.Text = "PegPlace37"
        '
        'PegPlace36
        '
        Me.PegPlace36.CMSEnabled = False
        Me.PegPlace36.Location = New System.Drawing.Point(132, 360)
        Me.PegPlace36.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace36.Name = "PegPlace36"
        Me.PegPlace36.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace36.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace36.TabIndex = 35
        Me.PegPlace36.Text = "PegPlace36"
        '
        'PegPlace35
        '
        Me.PegPlace35.CMSEnabled = False
        Me.PegPlace35.Location = New System.Drawing.Point(99, 360)
        Me.PegPlace35.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace35.Name = "PegPlace35"
        Me.PegPlace35.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace35.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace35.TabIndex = 34
        Me.PegPlace35.Text = "PegPlace35"
        '
        'PegPlace34
        '
        Me.PegPlace34.CMSEnabled = False
        Me.PegPlace34.Location = New System.Drawing.Point(66, 360)
        Me.PegPlace34.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace34.Name = "PegPlace34"
        Me.PegPlace34.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace34.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace34.TabIndex = 33
        Me.PegPlace34.Text = "PegPlace34"
        '
        'PegPlace33
        '
        Me.PegPlace33.CMSEnabled = False
        Me.PegPlace33.Location = New System.Drawing.Point(33, 360)
        Me.PegPlace33.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace33.Name = "PegPlace33"
        Me.PegPlace33.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace33.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace33.TabIndex = 32
        Me.PegPlace33.Text = "PegPlace33"
        '
        'PegPlace32
        '
        Me.PegPlace32.CMSEnabled = False
        Me.PegPlace32.Location = New System.Drawing.Point(132, 326)
        Me.PegPlace32.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace32.Name = "PegPlace32"
        Me.PegPlace32.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace32.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace32.TabIndex = 31
        Me.PegPlace32.Text = "PegPlace32"
        '
        'PegPlace31
        '
        Me.PegPlace31.CMSEnabled = False
        Me.PegPlace31.Location = New System.Drawing.Point(99, 326)
        Me.PegPlace31.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace31.Name = "PegPlace31"
        Me.PegPlace31.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace31.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace31.TabIndex = 30
        Me.PegPlace31.Text = "PegPlace31"
        '
        'PegPlace30
        '
        Me.PegPlace30.CMSEnabled = False
        Me.PegPlace30.Location = New System.Drawing.Point(66, 326)
        Me.PegPlace30.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace30.Name = "PegPlace30"
        Me.PegPlace30.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace30.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace30.TabIndex = 29
        Me.PegPlace30.Text = "PegPlace30"
        '
        'PegPlace29
        '
        Me.PegPlace29.CMSEnabled = False
        Me.PegPlace29.Location = New System.Drawing.Point(33, 326)
        Me.PegPlace29.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace29.Name = "PegPlace29"
        Me.PegPlace29.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace29.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace29.TabIndex = 28
        Me.PegPlace29.Text = "PegPlace29"
        '
        'PegPlace28
        '
        Me.PegPlace28.CMSEnabled = False
        Me.PegPlace28.Location = New System.Drawing.Point(132, 292)
        Me.PegPlace28.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace28.Name = "PegPlace28"
        Me.PegPlace28.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace28.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace28.TabIndex = 27
        Me.PegPlace28.Text = "PegPlace28"
        '
        'PegPlace27
        '
        Me.PegPlace27.CMSEnabled = False
        Me.PegPlace27.Location = New System.Drawing.Point(99, 292)
        Me.PegPlace27.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace27.Name = "PegPlace27"
        Me.PegPlace27.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace27.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace27.TabIndex = 26
        Me.PegPlace27.Text = "PegPlace27"
        '
        'PegPlace26
        '
        Me.PegPlace26.CMSEnabled = False
        Me.PegPlace26.Location = New System.Drawing.Point(66, 292)
        Me.PegPlace26.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace26.Name = "PegPlace26"
        Me.PegPlace26.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace26.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace26.TabIndex = 25
        Me.PegPlace26.Text = "PegPlace26"
        '
        'PegPlace25
        '
        Me.PegPlace25.CMSEnabled = False
        Me.PegPlace25.Location = New System.Drawing.Point(33, 292)
        Me.PegPlace25.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace25.Name = "PegPlace25"
        Me.PegPlace25.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace25.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace25.TabIndex = 24
        Me.PegPlace25.Text = "PegPlace25"
        '
        'PegPlace24
        '
        Me.PegPlace24.CMSEnabled = False
        Me.PegPlace24.Location = New System.Drawing.Point(132, 258)
        Me.PegPlace24.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace24.Name = "PegPlace24"
        Me.PegPlace24.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace24.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace24.TabIndex = 23
        Me.PegPlace24.Text = "PegPlace24"
        '
        'PegPlace23
        '
        Me.PegPlace23.CMSEnabled = False
        Me.PegPlace23.Location = New System.Drawing.Point(99, 258)
        Me.PegPlace23.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace23.Name = "PegPlace23"
        Me.PegPlace23.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace23.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace23.TabIndex = 22
        Me.PegPlace23.Text = "PegPlace23"
        '
        'PegPlace22
        '
        Me.PegPlace22.CMSEnabled = False
        Me.PegPlace22.Location = New System.Drawing.Point(66, 258)
        Me.PegPlace22.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace22.Name = "PegPlace22"
        Me.PegPlace22.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace22.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace22.TabIndex = 21
        Me.PegPlace22.Text = "PegPlace22"
        '
        'PegPlace21
        '
        Me.PegPlace21.CMSEnabled = False
        Me.PegPlace21.Location = New System.Drawing.Point(33, 258)
        Me.PegPlace21.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace21.Name = "PegPlace21"
        Me.PegPlace21.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace21.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace21.TabIndex = 20
        Me.PegPlace21.Text = "PegPlace21"
        '
        'PegPlace20
        '
        Me.PegPlace20.CMSEnabled = False
        Me.PegPlace20.Location = New System.Drawing.Point(132, 225)
        Me.PegPlace20.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace20.Name = "PegPlace20"
        Me.PegPlace20.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace20.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace20.TabIndex = 19
        Me.PegPlace20.Text = "PegPlace20"
        '
        'PegPlace19
        '
        Me.PegPlace19.CMSEnabled = False
        Me.PegPlace19.Location = New System.Drawing.Point(99, 225)
        Me.PegPlace19.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace19.Name = "PegPlace19"
        Me.PegPlace19.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace19.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace19.TabIndex = 18
        Me.PegPlace19.Text = "PegPlace19"
        '
        'PegPlace18
        '
        Me.PegPlace18.CMSEnabled = False
        Me.PegPlace18.Location = New System.Drawing.Point(66, 225)
        Me.PegPlace18.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace18.Name = "PegPlace18"
        Me.PegPlace18.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace18.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace18.TabIndex = 17
        Me.PegPlace18.Text = "PegPlace18"
        '
        'PegPlace17
        '
        Me.PegPlace17.CMSEnabled = False
        Me.PegPlace17.Location = New System.Drawing.Point(33, 225)
        Me.PegPlace17.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace17.Name = "PegPlace17"
        Me.PegPlace17.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace17.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace17.TabIndex = 16
        Me.PegPlace17.Text = "PegPlace17"
        '
        'PegPlace16
        '
        Me.PegPlace16.CMSEnabled = False
        Me.PegPlace16.Location = New System.Drawing.Point(132, 191)
        Me.PegPlace16.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace16.Name = "PegPlace16"
        Me.PegPlace16.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace16.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace16.TabIndex = 15
        Me.PegPlace16.Text = "PegPlace16"
        '
        'PegPlace15
        '
        Me.PegPlace15.CMSEnabled = False
        Me.PegPlace15.Location = New System.Drawing.Point(99, 191)
        Me.PegPlace15.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace15.Name = "PegPlace15"
        Me.PegPlace15.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace15.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace15.TabIndex = 14
        Me.PegPlace15.Text = "PegPlace15"
        '
        'PegPlace14
        '
        Me.PegPlace14.CMSEnabled = False
        Me.PegPlace14.Location = New System.Drawing.Point(66, 191)
        Me.PegPlace14.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace14.Name = "PegPlace14"
        Me.PegPlace14.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace14.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace14.TabIndex = 13
        Me.PegPlace14.Text = "PegPlace14"
        '
        'PegPlace13
        '
        Me.PegPlace13.CMSEnabled = False
        Me.PegPlace13.Location = New System.Drawing.Point(33, 191)
        Me.PegPlace13.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace13.Name = "PegPlace13"
        Me.PegPlace13.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace13.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace13.TabIndex = 12
        Me.PegPlace13.Text = "PegPlace13"
        '
        'PegPlace12
        '
        Me.PegPlace12.CMSEnabled = False
        Me.PegPlace12.Location = New System.Drawing.Point(132, 157)
        Me.PegPlace12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace12.Name = "PegPlace12"
        Me.PegPlace12.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace12.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace12.TabIndex = 11
        Me.PegPlace12.Text = "PegPlace12"
        '
        'PegPlace11
        '
        Me.PegPlace11.CMSEnabled = False
        Me.PegPlace11.Location = New System.Drawing.Point(99, 157)
        Me.PegPlace11.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace11.Name = "PegPlace11"
        Me.PegPlace11.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace11.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace11.TabIndex = 10
        Me.PegPlace11.Text = "PegPlace11"
        '
        'PegPlace10
        '
        Me.PegPlace10.CMSEnabled = False
        Me.PegPlace10.Location = New System.Drawing.Point(66, 157)
        Me.PegPlace10.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace10.Name = "PegPlace10"
        Me.PegPlace10.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace10.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace10.TabIndex = 9
        Me.PegPlace10.Text = "PegPlace10"
        '
        'PegPlace9
        '
        Me.PegPlace9.CMSEnabled = False
        Me.PegPlace9.Location = New System.Drawing.Point(33, 157)
        Me.PegPlace9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace9.Name = "PegPlace9"
        Me.PegPlace9.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace9.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace9.TabIndex = 8
        Me.PegPlace9.Text = "PegPlace9"
        '
        'PegPlace8
        '
        Me.PegPlace8.CMSEnabled = False
        Me.PegPlace8.Location = New System.Drawing.Point(132, 123)
        Me.PegPlace8.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace8.Name = "PegPlace8"
        Me.PegPlace8.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace8.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace8.TabIndex = 7
        Me.PegPlace8.Text = "PegPlace8"
        '
        'PegPlace7
        '
        Me.PegPlace7.CMSEnabled = False
        Me.PegPlace7.Location = New System.Drawing.Point(99, 123)
        Me.PegPlace7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace7.Name = "PegPlace7"
        Me.PegPlace7.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace7.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace7.TabIndex = 6
        Me.PegPlace7.Text = "PegPlace7"
        '
        'PegPlace6
        '
        Me.PegPlace6.CMSEnabled = False
        Me.PegPlace6.Location = New System.Drawing.Point(66, 123)
        Me.PegPlace6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace6.Name = "PegPlace6"
        Me.PegPlace6.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace6.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace6.TabIndex = 5
        Me.PegPlace6.Text = "PegPlace6"
        '
        'PegPlace5
        '
        Me.PegPlace5.CMSEnabled = False
        Me.PegPlace5.Location = New System.Drawing.Point(33, 123)
        Me.PegPlace5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace5.Name = "PegPlace5"
        Me.PegPlace5.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace5.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace5.TabIndex = 4
        Me.PegPlace5.Text = "PegPlace5"
        '
        'PegPlace4
        '
        Me.PegPlace4.CMSEnabled = False
        Me.PegPlace4.Location = New System.Drawing.Point(132, 58)
        Me.PegPlace4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace4.Name = "PegPlace4"
        Me.PegPlace4.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace4.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace4.TabIndex = 3
        Me.PegPlace4.Text = "PegPlace4"
        '
        'PegPlace3
        '
        Me.PegPlace3.CMSEnabled = False
        Me.PegPlace3.Location = New System.Drawing.Point(99, 58)
        Me.PegPlace3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace3.Name = "PegPlace3"
        Me.PegPlace3.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace3.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace3.TabIndex = 2
        Me.PegPlace3.Text = "PegPlace3"
        '
        'PegPlace2
        '
        Me.PegPlace2.CMSEnabled = False
        Me.PegPlace2.Location = New System.Drawing.Point(66, 58)
        Me.PegPlace2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace2.Name = "PegPlace2"
        Me.PegPlace2.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace2.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace2.TabIndex = 1
        Me.PegPlace2.Text = "PegPlace2"
        '
        'PegPlace1
        '
        Me.PegPlace1.CMSEnabled = False
        Me.PegPlace1.Location = New System.Drawing.Point(33, 58)
        Me.PegPlace1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PegPlace1.Name = "PegPlace1"
        Me.PegPlace1.pegColor = System.Drawing.SystemColors.Control
        Me.PegPlace1.Size = New System.Drawing.Size(24, 25)
        Me.PegPlace1.TabIndex = 0
        Me.PegPlace1.Text = "PegPlace1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(270, 786)
        Me.Controls.Add(Me.PegPlace78)
        Me.Controls.Add(Me.PegPlace77)
        Me.Controls.Add(Me.PegPlace76)
        Me.Controls.Add(Me.PegPlace75)
        Me.Controls.Add(Me.PegPlace74)
        Me.Controls.Add(Me.PegPlace73)
        Me.Controls.Add(Me.PegPlace72)
        Me.Controls.Add(Me.PegPlace71)
        Me.Controls.Add(Me.PegPlace70)
        Me.Controls.Add(Me.PegPlace69)
        Me.Controls.Add(Me.PegPlace68)
        Me.Controls.Add(Me.PegPlace67)
        Me.Controls.Add(Me.PegPlace66)
        Me.Controls.Add(Me.PegPlace65)
        Me.Controls.Add(Me.PegPlace64)
        Me.Controls.Add(Me.PegPlace63)
        Me.Controls.Add(Me.PegPlace62)
        Me.Controls.Add(Me.PegPlace61)
        Me.Controls.Add(Me.PegPlace60)
        Me.Controls.Add(Me.PegPlace59)
        Me.Controls.Add(Me.PegPlace58)
        Me.Controls.Add(Me.PegPlace57)
        Me.Controls.Add(Me.PegPlace56)
        Me.Controls.Add(Me.PegPlace55)
        Me.Controls.Add(Me.PegPlace54)
        Me.Controls.Add(Me.PegPlace53)
        Me.Controls.Add(Me.PegPlace52)
        Me.Controls.Add(Me.PegPlace51)
        Me.Controls.Add(Me.PegPlace50)
        Me.Controls.Add(Me.PegPlace49)
        Me.Controls.Add(Me.PegPlace48)
        Me.Controls.Add(Me.PegPlace47)
        Me.Controls.Add(Me.PegPlace46)
        Me.Controls.Add(Me.PegPlace45)
        Me.Controls.Add(Me.PegPlace44)
        Me.Controls.Add(Me.PegPlace43)
        Me.Controls.Add(Me.PegPlace42)
        Me.Controls.Add(Me.PegPlace41)
        Me.Controls.Add(Me.PegPlace40)
        Me.Controls.Add(Me.PegPlace39)
        Me.Controls.Add(Me.PegPlace38)
        Me.Controls.Add(Me.PegPlace37)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.btnCheck)
        Me.Controls.Add(Me.PegPlace36)
        Me.Controls.Add(Me.PegPlace35)
        Me.Controls.Add(Me.PegPlace34)
        Me.Controls.Add(Me.PegPlace33)
        Me.Controls.Add(Me.PegPlace32)
        Me.Controls.Add(Me.PegPlace31)
        Me.Controls.Add(Me.PegPlace30)
        Me.Controls.Add(Me.PegPlace29)
        Me.Controls.Add(Me.PegPlace28)
        Me.Controls.Add(Me.PegPlace27)
        Me.Controls.Add(Me.PegPlace26)
        Me.Controls.Add(Me.PegPlace25)
        Me.Controls.Add(Me.PegPlace24)
        Me.Controls.Add(Me.PegPlace23)
        Me.Controls.Add(Me.PegPlace22)
        Me.Controls.Add(Me.PegPlace21)
        Me.Controls.Add(Me.PegPlace20)
        Me.Controls.Add(Me.PegPlace19)
        Me.Controls.Add(Me.PegPlace18)
        Me.Controls.Add(Me.PegPlace17)
        Me.Controls.Add(Me.PegPlace16)
        Me.Controls.Add(Me.PegPlace15)
        Me.Controls.Add(Me.PegPlace14)
        Me.Controls.Add(Me.PegPlace13)
        Me.Controls.Add(Me.PegPlace12)
        Me.Controls.Add(Me.PegPlace11)
        Me.Controls.Add(Me.PegPlace10)
        Me.Controls.Add(Me.PegPlace9)
        Me.Controls.Add(Me.PegPlace8)
        Me.Controls.Add(Me.PegPlace7)
        Me.Controls.Add(Me.PegPlace6)
        Me.Controls.Add(Me.PegPlace5)
        Me.Controls.Add(Me.PegPlace4)
        Me.Controls.Add(Me.PegPlace3)
        Me.Controls.Add(Me.PegPlace2)
        Me.Controls.Add(Me.PegPlace1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "mastermind"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PegPlace1 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace2 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace3 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace4 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace5 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace6 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace7 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace8 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace9 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace10 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace11 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace12 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace13 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace14 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace15 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace16 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace17 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace18 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace19 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace20 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace21 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace22 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace23 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace24 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace25 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace26 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace27 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace28 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace29 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace30 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace31 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace32 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace33 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace34 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace35 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace36 As WindowsApplication2.pegPlace
    Friend WithEvents btnCheck As System.Windows.Forms.Button
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents PegPlace37 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace38 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace39 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace40 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace41 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace42 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace43 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace44 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace45 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace46 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace47 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace48 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace49 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace50 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace51 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace52 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace53 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace54 As WindowsApplication2.pegPlace
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripComboBox1 As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents PegPlace55 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace56 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace57 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace58 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace59 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace60 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace61 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace62 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace63 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace64 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace65 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace66 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace67 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace68 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace69 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace70 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace71 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace72 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace73 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace74 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace75 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace76 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace77 As WindowsApplication2.pegPlace
    Friend WithEvents PegPlace78 As WindowsApplication2.pegPlace

End Class
